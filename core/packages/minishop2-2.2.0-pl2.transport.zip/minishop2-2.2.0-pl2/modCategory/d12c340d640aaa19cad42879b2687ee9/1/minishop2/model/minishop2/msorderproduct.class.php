<?php
class msOrderProduct extends xPDOSimpleObject {}