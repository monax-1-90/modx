<?php
require_once (dirname(dirname(__FILE__)) . '/msproductdata.class.php');
class msProductData_mysql extends msProductData {}